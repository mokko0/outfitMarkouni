<?php
session_start();
@include "config.php";
// Controlla se la variabile di sessione 'name' è impostata
if (!isset($_SESSION['name'])) {
    // L'utente non ha effettuato l'accesso, reindirizzalo alla pagina di login
    header("Location: index.php");
    exit();
}

// Verifica la connessione al database
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

$id = $_SESSION['id'];

// Query per ottenere i dettagli dei prodotti nel carrello
$query = "SELECT carrello.id_prodotto, carrello.quantita, prodotti.immagine, prodotti.prezzo
          FROM carrello 
          INNER JOIN prodotti ON carrello.id_prodotto = prodotti.id 
          WHERE carrello.id_cliente = $id";

// Query per ottenere il totale dei prezzi dei prodotti nel carrello
$totalQuery = "SELECT SUM(prodotti.prezzo * carrello.quantita) AS Totale
               FROM carrello 
               INNER JOIN prodotti ON carrello.id_prodotto = prodotti.id 
               WHERE carrello.id_cliente = $id";

// Esegui le query
$result = $conn->query($query);
$totalResult = $conn->query($totalQuery);

// Verifica che le query siano state eseguite correttamente
if (!$result || !$totalResult) {
    // Gestisci eventuali errori nella query
    echo "Errore nella query: " . mysqli_error($conn);
} else {
    // Ottieni il totale come stringa
    $row = $totalResult->fetch_assoc();
    $totale = $row['Totale'];

}
$count = "SELECT count(*) FROM carrello";
$result_count = mysqli_query($conn, $count);
$row = mysqli_fetch_row($result_count);
 $count_string = $row[0];


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Maranza Shop</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="img/logo.png">
    <style>
.text-z{
    color: black !important;    
}
        </style>
</head>

<body>
    <!-- Topbar Start -->
    <div class="container-fluid">
       
        </div>
        <div class="row align-items-center py-3 px-xl-5">
            <div class="col-lg-3 d-none d-lg-block">
                <a href="home.php" class="text-decoration-none">
                    <h1 class="m-0 display-5 font-weight-semi-bold"><img src="img/logo.png" width="300" height="100"></h1>
                </a>
            </div>
            <div class="col-lg-6 col-6 text-left">
             
            </div>
            <div class="col-lg-3 col-6 text-right">
                <a href="cart.php" class="btn border">
                    <i class="fas fa-shopping-cart text-z"></i>
                    <span class="badge"><?php echo $count_string ?></span>
                </a>
            </div>
        </div>
    </div>
    <!-- Topbar End -->

 <!-- Navbar Start -->
 <div class="container-fluid mb-5">
        <div class="row border-top px-xl-5">
            <div class="col-lg-3 d-none d-lg-block">
                
               
            </div>
            <div class="col-lg-9">
                <nav class="navbar navbar-expand-lg bg-light navbar-light py-3 py-lg-0 px-0">
                    <a href="" class="text-decoration-none d-block d-lg-none">
                        <h1 class="m-0 display-5 font-weight-semi-bold"><span class="text-primary font-weight-bold border px-3 mr-1">E</span>Shopper</h1>
                    </a>
                    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                        <div class="navbar-nav mr-auto py-0">
                        
                            </div>
                            <a href="contact.php" class="nav-item nav-link">Contattaci</a>
                        </div>
                        <div class="navbar-nav ml-auto py-0">
                            <a href="logout.php" class="nav-item nav-link">Logout</a>
                        </div>   
        </div>
    </div>
    <!-- Navbar End -->

    <!-- Page Header Start -->
    <div class="container-fluid bg-secondary mb-5">
        <div class="d-flex flex-column align-items-center justify-content-center" style="min-height: 300px">
            <h1 class="font-weight-semi-bold text-uppercase mb-3">Carrello</h1>
            <div class="d-inline-flex">
                <p class="m-0"><a href="">Home</a></p>
                <p class="m-0 px-2">-</p>
                <p class="m-0">Carrello</p>
            </div>
        </div>
    </div>
    <!-- Page Header End -->

<!-- Carrello Start -->
<div class="container-fluid pt-5">
        <div class="row px-xl-5">
            <div class="col-lg-8 table-responsive mb-5">
                <table class="table table-bordered text-center mb-0">
                    <thead class="bg-secondary text-dark">
                        <tr>
                            <th>Prodotto</th>
                            <th>Prezzo</th>
                            <th>Quantità</th>
                            <th>Totale</th>
                            <th>Rimuovi</th>
                        </tr>
                    </thead>
                    <tbody class="align-middle">
                        <?php
                        if ($result->num_rows > 0) {
                            while($row = $result->fetch_assoc()) {
                                // Visualizza il prodotto nel carrello
                                ?>
                                <tr>
                                    <td class="align-middle"><img src="<?php echo $row['immagine']; ?>" style="width: 50px;"></td>
                                    <td class="align-middle">$<?php echo $row['prezzo']; ?></td>
                                    <td class="align-middle">
                                        <div class="input-group quantity mx-auto" style="width: 100px;">
                                            <div class="input-group-btn">
                                               
                                            </div>
                                            <input type="text" class="form-control form-control-sm bg-secondary text-center" value="<?php echo $row['quantita']; ?>">
                                          
                                        </div>
                                    </td>
                                    <td class="align-middle">$<?php echo $row['prezzo'] * $row['quantita']; ?></td>
                                    <td class="align-middle">
                                        <button class="btn btn-sm btn-primary btn-remove" data-product-id="<?php echo $row['id_prodotto'];?>">
                                            <i class="fa fa-times"></i>
                                        </button>
                                    </td>                               
                                 </tr>
                                <?php
                            }
                        } else {
                            echo "<tr><td colspan='5'>Nessun prodotto nel carrello.</td></tr>";
                        }

                        $conn->close();
                        ?>
                    </tbody>
                </table>
            </div>
            <div class="col-lg-4">
                <div class="card border-secondary mb-5">
                    <div class="card-header bg-secondary border-0">
                        <h4 class="font-weight-semi-bold m-0">Carrello</h4>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between mb-3 pt-1">
                            <h6 class="font-weight-medium">Subtotal</h6>
                            <h6 class="font-weight-medium"><?php echo $totale?></h6>
                        </div>
                        <div class="d-flex justify-content-between">
                            <h6 class="font-weight-medium">Shipping</h6>
                            <h6 class="font-weight-medium">$0</h6>
                        </div>
                    </div>
                    <div class="card-footer border-secondary bg-transparent">
                        <div class="d-flex justify-content-between mt-2">
                            <h5 class="font-weight-bold">Total</h5>
                            <h5 class="font-weight-bold"><?php echo $totale?></h5>
                        </div>
                        <button class="btn btn-block btn-primary my-3 py-3" onclick="location.href='checkout.php';">Procedi Al Checkout</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Cart End -->

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

    <!-- Footer Start -->
    <div class="container-fluid bg-secondary text-dark mt-5 pt-5">
        <div class="row px-xl-5 pt-5">
            <div class="col-lg-4 col-md-12 mb-5 pr-3 pr-xl-5">
                <a href="" class="text-decoration-none">
                    <h1 class="mb-4 display-5 font-weight-semi-bold"><img src="img/logo.png" width="300" height="100"></h1>
                </a>
               
            </div>
            <div class="col-lg-8 col-md-12">
                <div class="row">
                    <div class="col-md-4 mb-5">
                        <h5 class="font-weight-bold text-dark mb-4">Dove Trovarci</h5>
                        <div class="d-flex flex-column justify-content-start">
                        <p>#FREESIMBA, #FREEBABY</p>
                <p class="mb-2"><i class="fa fa-map-marker-alt text-primary mr-3"></i>San Vittore, Milano</p>
                <p class="mb-2"><i class="fa fa-envelope text-primary mr-3"></i>cc.milano@giustizia.it</p>
                <p class="mb-0"><i class="fa fa-phone-alt text-primary mr-3"></i>024385211</p>
                        </div>
                    </div>
                    
                    </div>
                    <div class="col-md-4 mb-5">
                      
                    </div>
                </div>
            </div>
        </div>
        <div class="row border-top border-light mx-xl-5 py-4">
            <div class="col-md-6 px-xl-0">
                <p class="mb-md-0 text-center text-md-left text-dark">
                    &copy; <a class="text-dark font-weight-semi-bold" href="#">Maranza Shop by Z</a>
                </p>
            </div>
            <div class="col-md-6 px-xl-0 text-center text-md-right">
                <img class="img-fluid" src="img/payments.png" alt="">
            </div>
        </div>
    </div>
    <!-- Footer End -->



    <!-- Back to Top -->
    <a href="#" class="btn btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>

    <script>
        $(document).ready(function() {
            // Gestisce il clic sul pulsante "Rimuovi"
            $('.btn-remove').click(function() {
                var productId = $(this).data('product-id');
                // Invia una richiesta AJAX per rimuovere il prodotto dal carrello
                $.ajax({
                    url: 'remove_product.php',
                    type: 'POST',
                    data: { product_id: productId },
                    success: function(response) {
                        // Rimuovi dinamicamente la riga del prodotto dal carrello
                        $(this).closest('tr').remove();
                        // Aggiorna la pagina
                        window.location.reload(true);
                    }
                });
            });
        });
    </script>
</body>

</html>