<?php
session_start();
include "config.php";

if(isset($_POST['product_id']) && isset($_POST['user_id']) && isset($_POST['quantity'])) {
    $productId = $_POST['product_id'];
    $userId = $_POST['user_id'];
    $quantity = $_POST['quantity'];
    
    // Esegui l'inserimento nel database
    $query = "INSERT INTO carrello (id_cliente, id_prodotto, quantita) VALUES ('$userId', '$productId', $quantity)";
    if(mysqli_query($conn, $query)) {
        echo "Prodotto aggiunto al carrello!";
    } else {
        echo "Errore SQL: " . mysqli_error($conn);
        echo  $userId;
   
    }
} else {
    echo "Parametri mancanti per l'aggiunta del prodotto al carrello.";
}
?>