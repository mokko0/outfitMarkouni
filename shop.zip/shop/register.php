<?php

session_start();

@include "config.php";

if (isset($_POST["submit"])) {
    $name = mysqli_real_escape_string($conn, $_POST["name"]);
    $surname = mysqli_real_escape_string($conn, $_POST["surname"]);
    $email = mysqli_real_escape_string($conn, $_POST["email"]);
    $pass = md5($_POST["password"]);
    $cpass = md5($_POST["cpassword"]);
    $select = " SELECT * FROM users WHERE email = '$email' && password = '$pass'  && surname = '$surname'";

    $result = mysqli_query($conn, $select);

    if (mysqli_num_rows($result) > 0) {
        $error[] = "user already exist!";
    } else {
        if ($pass != $cpass) {
            
            $error[] = "password not matched!";
        } else {
            $insert = "INSERT INTO users (name, surname, email, password) VALUES('$name', '$surname','$email','$pass')";
            mysqli_query($conn, $insert);
            $_SESSION['name'] = $name;
            header("location:index.php");
        }
    }
}
?>
<!doctype html>
<html lang="en">
  <head>
  <title>Maranza Shop</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700&display=swap" rel="stylesheet">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<link rel="stylesheet" href="loginform/css/style.css">
    <link rel="icon" type="image/x-icon" href="img/logo.png">
    <style>
        body{
        background-image: url("img/bg.jpg");
        background-size: 100%;
        }
    </style>
	</head>
	<body>
	<section class="ftco-section">
    <div class="container">
        <div class="row justify-content-center">
          
        </div>
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-4">
                <div class="login-wrap py-5">
                    <div class="img d-flex align-items-center justify-content-center" style="background-image: url(loginform/images/maranza.jpg);"></div>
                    <h3 class="text-center mb-0">Benvenuto</h3>
                    <p class="text-center">Accedi con le tue Credenziali</p>
					<form method="post" class="login-form">
					<?php if (isset($error)) {
             foreach ($error as $error) {
                 echo '<span class="error-msg">' . $error . "</span>";
             }
         } ?>
                         <div class="form-group">
                            <div class="icon d-flex align-items-center justify-content-center"><span class="fa fa-user"></span></div>
                            <input type="text" name="name" class="form-control" placeholder="Nome" required>
                        </div>
                        <div class="form-group">
                            <div class="icon d-flex align-items-center justify-content-center"><span class="fa fa-user"></span></div>
                            <input type="text" name="surname" class="form-control" placeholder="Cognome" required>
                        </div>
                        <div class="form-group">
                            <div class="icon d-flex align-items-center justify-content-center"><span class="fa fa-user"></span></div>
                            <input type="text" name="email" class="form-control" placeholder="Email" required>
                        </div>
                        <div class="form-group">
                            <div class="icon d-flex align-items-center justify-content-center"><span class="fa fa-lock"></span></div>
                            <input type="password" name="password" class="form-control" placeholder="Password" required>
                        </div>
                        <div class="form-group">
                            <div class="icon d-flex align-items-center justify-content-center"><span class="fa fa-lock"></span></div>
                            <input type="password" name="cpassword" class="form-control" placeholder="Conferma Password" required>
                        </div>
                        <div class="form-group d-md-flex"></div>
                        <div class="form-group">
                            <button type="submit" name="submit" class="btn form-control btn-primary rounded submit px-3">Registrati</button>
                        </div>
                    </form>
                    <div class="w-100 text-center mt-4 text">
                        <p class="mb-0">Hai già un account?</p>
                        <a href="index.php">Accedi</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script src="loginform/js/jquery.min.js"></script>
<script src="loginform/js/popper.js"></script>
<script src="loginform/js/bootstrap.min.js"></script>
<script src="loginform/js/main.js"></script>

</body>
</html>

