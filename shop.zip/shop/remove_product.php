<?php
session_start();
@include "config.php";
// Verifica se è stata ricevuta una richiesta POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Controlla la connessione
    if ($conn->connect_error) {
        die("Connessione fallita: " . $conn->connect_error);
    }

    // Ottieni l'id del prodotto dalla richiesta POST
    $productId = $_POST['product_id'];
    $id_user=$_SESSION['id'];
    // Prepara e esegui la query per rimuovere il prodotto dal carrello
    $query = "DELETE FROM carrello WHERE id_prodotto = $productId AND id_cliente=$id_user";

    if ($conn->query($query) === TRUE) {
        // Invia una risposta di successo se la rimozione è avvenuta con successo
        echo "Prodotto rimosso dal carrello con successo.";
    } else {
        // Invia un messaggio di errore se la rimozione ha fallito
        echo "Errore durante la rimozione del prodotto dal carrello: " . $conn->error;
    }

    // Chiudi la connessione al database
    $conn->close();
} else {
    // Se la richiesta non è una richiesta POST, invia un messaggio di errore
    echo "Metodo di richiesta non valido.";
}
?>