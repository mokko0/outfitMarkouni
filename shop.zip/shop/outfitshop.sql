-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Mag 24, 2024 alle 19:57
-- Versione del server: 10.4.32-MariaDB
-- Versione PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `outfitshop`
--
CREATE DATABASE IF NOT EXISTS `outfitshop` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `outfitshop`;

-- --------------------------------------------------------

--
-- Struttura della tabella `carrello`
--

CREATE TABLE `carrello` (
  `id_carrello` int(11) NOT NULL,
  `id_cliente` int(11) NOT NULL,
  `id_prodotto` int(11) NOT NULL,
  `quantita` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struttura della tabella `categorie`
--

CREATE TABLE `categorie` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `categorie`
--

INSERT INTO `categorie` (`id`, `nome`) VALUES
(1, 'tute'),
(2, 'cinture'),
(3, 'cappellini'),
(4, 'giubotti'),
(5, 'scarpe'),
(6, 'sacoche');

-- --------------------------------------------------------

--
-- Struttura della tabella `prodotti`
--

CREATE TABLE `prodotti` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `descrizione` text DEFAULT NULL,
  `prezzo` decimal(10,2) NOT NULL,
  `immagine` varchar(255) DEFAULT NULL,
  `categoria_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `prodotti`
--

INSERT INTO `prodotti` (`id`, `nome`, `descrizione`, `prezzo`, `immagine`, `categoria_id`) VALUES
(1, 'Tuta PSG', 'La tuta ufficiale del Paris Saint-Germain incarna lo spirito vincente e l eleganza parigina. Realizzata con materiali di alta qualità, questa tuta offre comfort e stile ineguagliabili. Il colore blu scuro è arricchito da dettagli rossi e bianchi, con il logo del PSG in evidenza sul petto e sui pantaloni. La giacca presenta una chiusura a zip completa e pratiche tasche laterali, mentre i pantaloni vantano una vestibilità comoda con vita elasticizzata e caviglie elastiche. Ideale per l allenamento o il relax, questa tuta è un must-have per ogni vero tifoso parigino.', 49.99, 'images/tute/psg.webp', 1),
(2, 'Tuta Nike Sky Blue', 'La tuta Nike Sky Blue unisce stile e funzionalità in un unica soluzione. Realizzata con materiali di alta qualità, questa tuta presenta un design moderno e accattivante. Il colore blu cielo conferisce un tocco fresco e vivace, mentre i dettagli bianchi aggiungono un tocco di contrasto elegante. La giacca offre una vestibilità comoda con chiusura a zip completa e tasche laterali, perfette per tenere al sicuro gli oggetti personali. I pantaloni, con vita elasticizzata e polsini a costine, assicurano una vestibilità regolabile e confortevole. Sia per l attività sportiva che per il tempo libero, questa tuta Nike è la scelta ideale per chi cerca uno stile dinamico e all avanguardia.', 59.99, 'images/tute/Sky_Blue_nike.jpg', 1),
(3, 'Nike Tech', 'La tuta Nike Tech rappresenta l unione perfetta tra stile urbano e prestazioni ottimali. Realizzata con tessuti tecnici di alta qualità, questa tuta offre un comfort superiore e un look sofisticato. La giacca presenta un design pulito con una chiusura a zip completa e dettagli minimali, mentre i pantaloni vantano una vestibilità comoda con vita elasticizzata e polsini a costine. Il tessuto traspirante e leggero assicura una sensazione di freschezza e libertà di movimento durante l attività fisica o le giornate di relax in città. Con il logo Nike discretamente posizionato, questa tuta incarna lo spirito dell eccellenza sportiva e dello stile senza tempo.', 99.99, 'images/tute/technike.webp', 1),
(4, 'Tuta Trapstar Shooters', 'La tuta Trapstar Shooters è un icona di stile urbano e di streetwear. Caratterizzata da dettagli audaci e un design distintivo, questa tuta cattura l essenza dell urban culture. La giacca presenta un taglio sagomato e dettagli accattivanti come zip esposte e tasche multiple, mentre i pantaloni offrono una vestibilità comoda con una silhouette affusolata e dettagli street-inspired. Il logo Trapstar è in evidenza su entrambi i capi, conferendo un tocco di autenticità e originalità. Realizzata con materiali di alta qualità, questa tuta unisce stile e comfort per creare un look unico e audace che si distingue nella folla.', 42.99, 'images/tute/trapstar_shooters.png', 1),
(5, 'Tuta Puma', 'La tuta Puma incarna lo spirito dell atletica e dello stile contemporaneo. Realizzata con materiali di alta qualità e un design innovativo, questa tuta offre prestazioni ottimali e un look alla moda. La giacca presenta un taglio sportivo con una chiusura a zip completa e dettagli iconici del marchio Puma, mentre i pantaloni offrono una vestibilità comoda con vita elasticizzata e polsini a costine. Il logo Puma è in evidenza su entrambi i capi, conferendo un tocco di autenticità e dinamismo. Ideale per l allenamento o il tempo libero, questa tuta è un aggiunta essenziale al guardaroba di ogni appassionato di sport e di stile.', 35.99, 'images/tute/tutapuma.jpg', 1),
(6, 'Tuta Y2K', 'La tuta Y2K rappresenta un ode al glamour e alla futuristica moda degli anni 2000. Caratterizzata da tagli audaci e dettagli eccentrici, questa tuta cattura lo spirito ribelle e l energia della cultura giovanile di quel periodo. La giacca presenta linee sinuose e colori vivaci, arricchiti da dettagli metallici e zip esposte, mentre i pantaloni offrono una silhouette ampia e comoda con dettagli sartoriali unici. I tessuti lucidi e riflettenti, insieme ai dettagli futuristici come cinture a strappo e fibbie oversize, conferiscono a questa tuta un look audace e distintivo. Perfetta per chi cerca uno stile ribelle e un omaggio al passato, la tuta Y2K è un icona di moda che continua a ispirare e sorprendere.', 37.99, 'images/tute/y2k_streewear.jpg', 1),
(7, 'Cintura CK Nera', 'La cintura Calvin Klein nera è un icona di stile minimalista ed eleganza senza tempo. Realizzata in pelle di alta qualità, presenta una fibbia discreta con il logo CK distintivo, aggiungendo un tocco di raffinatezza ad ogni outfit. Versatile e sofisticata, questa cintura completa il look con un tocco di classe e semplicità.', 69.99, 'images/cinture/ck_nera.jpg', 2),
(8, 'Cintura Gucci Lucida', 'La cintura Gucci lucida incarna l esclusività e lo spirito lussuoso del marchio italiano. Caratterizzata da una finitura brillante e impeccabile, questa cintura è realizzata con materiali pregiati e presenta la distintiva fibbia GG di Gucci, simbolo di status e stile sofisticato. Perfetta per chi ama distinguersi con eleganza, questa cintura aggiunge un tocco di glamour ad ogni look.', 84.99, 'images/cinture/gucci_lucida.jpg', 2),
(9, 'Cintura Gucci Nera', 'La cintura Gucci nera incarna l eleganza senza tempo con un tocco di modernità. Realizzata in pelle nera di alta qualità, presenta la classica fibbia a GG in metallo dorato che aggiunge un tocco distintivo e iconico. Questo accessorio versatile può essere indossato con qualsiasi outfit, dall abbigliamento formale a quello casual, conferendo un tocco di stile sofisticato a qualsiasi look.', 79.99, 'images/cinture/gucci_nera.jpg', 2),
(10, 'Cintura LV Bianca', 'La cintura Louis Vuitton bianca è un simbolo di raffinatezza e stile senza tempo. Realizzata con la distintiva tela Monogram LV, questa cintura aggiunge un tocco di lusso ad ogni outfit. La fibbia elegante e minimalista, spesso impreziosita dal logo LV, completa il design, conferendo un eleganza discreta ma sofisticata. Perfetta per ogni occasione, questa cintura bianca è un icona di classe e gusto impeccabile.', 94.99, 'images/cinture/lv_bianca.jpg', 2),
(11, 'Cintura LV Nera', 'La cintura Louis Vuitton nera è un icona di stile e raffinatezza. Realizzata con la pregiata pelle nera della maison, questa cintura offre un eleganza senza tempo. La fibbia, spesso impreziosita dal logo LV, aggiunge un tocco distintivo e lussuoso al design. Versatile e sofisticata, questa cintura nera è l accessorio perfetto per completare ogni look, sia formale che casual, conferendo un tocco di classe inconfondibile.', 129.99, 'images/cinture/lv_nera.webp', 2),
(12, 'Cintura LV Prisma', 'La cintura Louis Vuitton Prisma incarna l eleganza contemporanea con un tocco di raffinatezza. Realizzata con la caratteristica pelle Monogram LV, questa cintura presenta una fibbia pratica e sofisticata con dettagli geometrici ispirati al prisma, che aggiungono un tocco di modernità al design classico. Versatile e distintiva, la cintura LV Prisma è l accessorio perfetto per completare qualsiasi outfit, dal casual all elegante, conferendo un eleganza senza tempo con un tocco di originalità.', 149.99, 'images/cinture/lv_prisma.webp', 2),
(13, 'Cappellino CK', 'Il cappellino CK è un icona di stile casual con il logo distintivo di Calvin Klein prominente sul davanti. Solitamente realizzato in materiali di alta qualità come il cotone o il denim, presenta una visiera curva e una chiusura regolabile sul retro per una vestibilità personalizzata. È un accessorio versatile che aggiunge un tocco di eleganza urbana a qualsiasi outfit.', 32.99, 'images/cappellini/ck.webp', 3),
(14, 'Gucci Maroc', 'Il cappellino Gucci Maroc è un accessorio di lusso che incarna lo stile distintivo e l eleganza di Gucci. Caratterizzato dal logo iconico del marchio, può presentare dettagli ricamati, stampe vivaci o motivi distintivi ispirati al Marocco, come arabeschi o motivi floreali. Realizzato con materiali pregiati come il cotone, la lana o la seta, offre un elevata qualità artigianale e una vestibilità confortevole. È un elemento di moda di tendenza che aggiunge un tocco di esclusività e raffinatezza a qualsiasi outfit.', 99.99, 'images/cappellini/gucci_maroc.png', 3),
(15, 'Gucci Snake', 'Il cappellino Gucci Snake è un icona di stile che incarna l estetica audace e lussuosa del marchio Gucci. Caratterizzato dal motivo del serpente, simbolo di saggezza e potenza, è spesso realizzato in tessuti di alta qualità come il cotone o la lana. Il serpente può essere ricamato o stampato sul cappellino, creando un effetto visivo vivace e distintivo. Con una visiera curva e una chiusura regolabile sul retro, offre una vestibilità comoda e personalizzata. È un accessorio di tendenza che conferisce un tocco di glamour e individualità a qualsiasi look.', 84.99, 'images/cappellini/gucci_snake.webp', 3),
(16, 'LV Azzurro', 'Il cappellino LV azzurro è un elegante interpretazione dell iconico stile di Louis Vuitton. Realizzato con materiali di alta qualità come il cotone o la lana, presenta il distintivo monogramma LV del marchio in un tono azzurro sofisticato. La visiera curva e la chiusura regolabile sul retro assicurano una vestibilità comoda e personalizzata. Questo accessorio aggiunge un tocco di classe e raffinatezza a qualsiasi outfit, perfetto per un look casual chic sia di giorno che di sera.', 74.99, 'images/cappellini/lv_azzurra.jpg', 3),
(17, 'LV Nero', 'Il cappellino LV nero è un icona di eleganza e stile senza tempo firmata Louis Vuitton. Realizzato con materiali di alta qualità come il cotone o la lana, presenta il classico monogramma LV del marchio in un ricco nero profondo. Con una visiera curva e una chiusura regolabile sul retro, offre una vestibilità confortevole e personalizzata. Questo accessorio versatile è perfetto per completare un look casual o aggiungere un tocco di sofisticazione a un outfit più formale.', 54.99, 'images/cappellini/lv_nera.webp', 3),
(18, 'NY', 'Il cappellino NY Yankees è un icona di stile intramontabile associata alla cultura urbana e allo sport. Caratterizzato dal logo distintivo degli Yankees di New York ricamato sul davanti, questo cappellino è solitamente realizzato in cotone resistente o in materiale misto, con una visiera curva e una chiusura regolabile sul retro per una vestibilità personalizzata. La sua semplicità e versatilità lo rendono un accessorio ideale per completare un look casual e sportivo, mentre il suo status iconico lo rende una scelta popolare per gli appassionati di baseball e gli amanti dello streetwear.', 24.99, 'images/cappellini/New_York_Yankees.jpg', 3),
(19, 'Blauer', 'Blauer è un marchio noto per i suoi capi d abbigliamento di alta qualità, in particolare i giubbotti. I giubbotti Blauer sono riconosciuti per il loro design funzionale e lo stile contemporaneo, unendo estetica e praticità. Originariamente creati per le forze dell ordine e il personale militare negli Stati Uniti, questi giubbotti sono realizzati con materiali resistenti e tecnologie avanzate, garantendo comfort, durabilità e protezione. Caratterizzati da linee pulite e dettagli accurati, i giubbotti Blauer si adattano sia a contesti urbani che outdoor, rappresentando una scelta ideale per chi cerca un capo versatile e affidabile.', 134.40, 'images/giubotti/Blauer.jpg', 4),
(20, 'McKenzie', 'Il giubbotto McKenzie è un capo d abbigliamento casual noto per il suo stile moderno e funzionale. Creato per offrire comfort e protezione nelle giornate fredde, il giubbotto McKenzie è realizzato con materiali di qualità che assicurano durabilità e isolamento termico. Spesso caratterizzato da un design sportivo e dettagli pratici come cappucci regolabili, tasche multiple e cerniere robuste, questo giubbotto si adatta perfettamente a un look urbano. Ideale per chi cerca un capo versatile e alla moda, il giubbotto McKenzie combina estetica e praticità per affrontare con stile le sfide del clima quotidiano.', 119.99, 'images/giubotti/McKenzie.webp', 4),
(21, 'Moncler', 'Il giubbotto Moncler è un capo d abbigliamento di lusso noto per la sua eccellenza nel design e nella qualità dei materiali. Fondata nel 1952, Moncler è diventata sinonimo di eleganza e performance, specializzandosi in capi imbottiti in piuma d oca. I giubbotti Moncler sono apprezzati per il loro stile sofisticato, il taglio impeccabile e l attenzione ai dettagli. Realizzati per offrire calore e protezione contro il freddo, questi giubbotti uniscono funzionalità tecnica a un estetica raffinata, rendendoli ideali sia per l uso urbano che per le attività outdoor. Indossare un giubbotto Moncler significa scegliere un capo iconico, che rappresenta il perfetto equilibrio tra moda e prestazioni.', 199.99, 'images/giubotti/mocler.webp', 4),
(22, 'TrapStar Lucido', 'Il giubbotto Trapstar Lucido è un capo d abbigliamento distintivo, noto per il suo stile urbano e audace. Trapstar, un marchio londinese celebre per la sua influenza nella cultura streetwear, ha creato questo giubbotto con un design lucido che cattura immediatamente l attenzione. Realizzato con materiali di alta qualità che conferiscono al capo un aspetto brillante e contemporaneo, il giubbotto Trapstar Lucido è spesso caratterizzato da dettagli accattivanti come stampe grafiche, loghi vistosi e finiture di tendenza. Ideale per chi desidera un look moderno e audace, questo giubbotto rappresenta una dichiarazione di stile e personalità nel mondo della moda urbana.', 169.99, 'images/giubotti/trapstar_lucido.jpg', 4),
(23, 'TrapStar Shooters', 'Il giubbotto Trapstar Shooters è un capo d abbigliamento iconico, noto per il suo design grintoso e l estetica streetwear. Trapstar, un marchio londinese influente nella cultura urbana, ha creato questo giubbotto per coloro che cercano uno stile audace e distintivo. Caratterizzato da una silhouette robusta e dettagli tecnici, il giubbotto Shooters spesso include tasche multiple, chiusure con cerniera e distintivi loghi Trapstar. Realizzato con materiali di alta qualità per garantire durabilità e comfort, questo giubbotto si distingue per il suo look contemporaneo e funzionale. Ideale per affrontare la città con stile, il giubbotto Trapstar Shooters rappresenta una perfetta combinazione di moda e praticità.', 129.99, 'images/giubotti/trapstar_shooters.webp', 4),
(24, 'Nike Air Max 97', 'Le Nike Air Max 97 sono un iconica linea di sneakers, celebre per il suo design futuristico e l innovativa tecnologia di ammortizzazione. Lanciate per la prima volta nel 1997, queste scarpe si distinguono per le loro linee ondulate ispirate ai treni proiettile giapponesi e la tomaia realizzata con materiali misti come mesh e pelle sintetica. La caratteristica più distintiva delle Air Max 97 è l unità Air visibile a tutta lunghezza, che offre un comfort eccezionale e una risposta reattiva ad ogni passo. Disponibili in una varietà di colorazioni e edizioni speciali, le Nike Air Max 97 continuano a essere una scelta amata sia dagli appassionati di sneaker che dagli amanti della moda urbana, grazie al loro mix di stile e performance.', 129.99, 'images/scarpe/air_max97.webp', 5),
(25, 'Air Force 1-Custom', 'Le Nike Air Force 1 Custom sono una reinterpretazione personalizzata delle classiche Air Force 1, un modello iconico che ha lasciato un impronta indelebile nel mondo delle sneaker sin dal suo lancio nel 1982. Queste scarpe offrono una tela bianca perfetta per esprimere la propria creatività attraverso colori, disegni e materiali unici. Con la loro silhouette inconfondibile e la suola con unità Air per un ammortizzazione superiore, le Air Force 1 Custom combinano comfort e stile personalizzato. Che si tratti di dettagli dipinti a mano, applicazioni di tessuti o aggiunta di elementi distintivi, le Nike Air Force 1 Custom rappresentano una dichiarazione di individualità e originalità, ideali per chi desidera un look unico e alla moda.', 189.99, 'images/scarpe/custom_nike.jpg', 5),
(26, 'LV Skate', 'Le scarpe LV Skate sono una creazione di lusso della maison Louis Vuitton, che fonde l alta moda con l estetica streetwear. Ispirate al mondo dello skateboard, queste scarpe combinano design contemporaneo e materiali pregiati, come pelle di alta qualità e dettagli esclusivi. Caratterizzate da una silhouette robusta e confortevole, le LV Skate presentano dettagli distintivi come il monogramma LV, cuciture elaborate e suole durevoli che garantiscono trazione e stabilità. Ideali per chi cerca uno stile sofisticato con un tocco urbano, le scarpe LV Skate rappresentano una perfetta unione di artigianalità e moda moderna.', 249.99, 'images/scarpe/lv_skate.jpg', 5),
(27, 'Nike Air Max Plus Azzurre', 'Le Nike Air Max Plus Azzurre sono una variante elegante e vibrante delle iconiche sneakers Air Max Plus, famose per il loro design audace e l innovativa tecnologia Tuned Air. Queste scarpe si distinguono per la loro accattivante colorazione azzurra, che aggiunge un tocco fresco e dinamico al look. La tomaia è realizzata in materiali traspiranti e durevoli, con linee ondulate e dettagli in rilievo che richiamano il design originale del modello lanciato nel 1998. L unità Tuned Air, visibile nella suola, offre un ammortizzazione reattiva e un supporto eccellente. Le Nike Air Max Plus Azzurre sono ideali per chi desidera unire comfort e stile in un unica calzatura distintiva, perfetta per completare qualsiasi outfit urbano.', 149.99, 'images/scarpe/nike_air_max_plus_azzurre.png', 5),
(28, 'Nike Air Max Plus Nere', 'Le Nike Air Max Plus Nere sono una variante elegante e vibrante delle iconiche sneakers Air Max Plus, famose per il loro design audace e l innovativa tecnologia Tuned Air. Queste scarpe si distinguono per la loro accattivante colorazione azzurra, che aggiunge un tocco fresco e dinamico al look. La tomaia è realizzata in materiali traspiranti e durevoli, con linee ondulate e dettagli in rilievo che richiamano il design originale del modello lanciato nel 1998. L unità Tuned Air, visibile nella suola, offre un ammortizzazione reattiva e un supporto eccellente. Le Nike Air Max Plus Azzurre sono ideali per chi desidera unire comfort e stile in un unica calzatura distintiva, perfetta per completare qualsiasi outfit urbano.', 149.99, 'images/scarpe/nike_air_max_plus_nere.webp', 5),
(29, 'Nike Air Max Plus Rosse', 'Le Nike Air Max Plus Rosse sono una variante elegante e vibrante delle iconiche sneakers Air Max Plus, famose per il loro design audace e l innovativa tecnologia Tuned Air. Queste scarpe si distinguono per la loro accattivante colorazione azzurra, che aggiunge un tocco fresco e dinamico al look. La tomaia è realizzata in materiali traspiranti e durevoli, con linee ondulate e dettagli in rilievo che richiamano il design originale del modello lanciato nel 1998. L unità Tuned Air, visibile nella suola, offre un ammortizzazione reattiva e un supporto eccellente. Le Nike Air Max Plus Azzurre sono ideali per chi desidera unire comfort e stile in un unica calzatura distintiva, perfetta per completare qualsiasi outfit urbano.', 149.99, 'images/scarpe/nike_air_max_plus_rosse.jpg', 5),
(30, 'Sacoche Fendi', 'La Sacoche Fendi è un accessorio di lusso che unisce funzionalità ed eleganza in un design compatto e raffinato. Realizzata con materiali pregiati come pelle di alta qualità e dettagli in metallo, questa borsa a tracolla è perfetta per chi desidera un accessorio pratico senza rinunciare allo stile. Caratterizzata dall iconico logo Fendi e da un attenta cura nei dettagli, la Sacoche Fendi offre diverse tasche e scomparti per organizzare al meglio gli oggetti personali. ', 129.99, 'images/sacoche/sacoche_fendi.jpg', 6),
(31, 'Sacoche Gucci', 'La Sacoche Gucci è un accessorio di lusso che incarna lo stile distintivo e l eleganza della maison italiana Gucci. Realizzata con materiali di alta qualità come pelle pregiata o tessuti GG Supreme monogrammati, questa borsa a tracolla offre un design sofisticato e funzionale. Caratterizzata dall iconico logo Double G e da dettagli raffinati come fibbie e catene, la Sacoche Gucci è disponibile in una varietà di stili e colori, adattandosi a diverse occasioni e gusti personali. ', 149.99, 'images/sacoche/sacoche_gucci.webp', 6),
(32, 'Sacoche LV', 'La Sacoche LV è un accessorio di lusso che incarna lo stile distintivo e l eleganza della maison italiana Gucci. Realizzata con materiali di alta qualità come pelle pregiata o tessuti GG Supreme monogrammati, questa borsa a tracolla offre un design sofisticato e funzionale. Caratterizzata dall iconico logo Double G e da dettagli raffinati come fibbie e catene, la Sacoche Gucci è disponibile in una varietà di stili e colori, adattandosi a diverse occasioni e gusti personali. ', 189.99, 'images/sacoche/sacoche_lv.webp', 6),
(33, 'Sacoche Trapstar', 'La Sacoche Trapstar è un accessorio di lusso che incarna lo stile distintivo e l eleganza della maison italiana Gucci. Realizzata con materiali di alta qualità come pelle pregiata o tessuti GG Supreme monogrammati, questa borsa a tracolla offre un design sofisticato e funzionale. Caratterizzata dall iconico logo Double G e da dettagli raffinati come fibbie e catene, la Sacoche Gucci è disponibile in una varietà di stili e colori, adattandosi a diverse occasioni e gusti personali. ', 119.99, 'images/sacoche/sacoche_trapstar.jpg', 6);

-- --------------------------------------------------------

--
-- Struttura della tabella `users`
--

CREATE TABLE `users` (
  `id_client` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `surname` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `users`
--

INSERT INTO `users` (`id_client`, `name`, `email`, `surname`, `password`) VALUES
(5, 'z', 'z@gmail.com', 'z', '6512bd43d9caa6e02c990b0a82652dca');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `carrello`
--
ALTER TABLE `carrello`
  ADD PRIMARY KEY (`id_carrello`),
  ADD KEY `FK_Carrello_Cliente` (`id_cliente`),
  ADD KEY `FK_Carrello_Prodotto` (`id_prodotto`);

--
-- Indici per le tabelle `categorie`
--
ALTER TABLE `categorie`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `prodotti`
--
ALTER TABLE `prodotti`
  ADD PRIMARY KEY (`id`),
  ADD KEY `categoria_id` (`categoria_id`);

--
-- Indici per le tabelle `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_client`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `carrello`
--
ALTER TABLE `carrello`
  MODIFY `id_carrello` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT per la tabella `categorie`
--
ALTER TABLE `categorie`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT per la tabella `prodotti`
--
ALTER TABLE `prodotti`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT per la tabella `users`
--
ALTER TABLE `users`
  MODIFY `id_client` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `carrello`
--
ALTER TABLE `carrello`
  ADD CONSTRAINT `FK_Carrello_Cliente` FOREIGN KEY (`id_cliente`) REFERENCES `users` (`id_client`),
  ADD CONSTRAINT `FK_Carrello_Prodotto` FOREIGN KEY (`id_prodotto`) REFERENCES `prodotti` (`id`);

--
-- Limiti per la tabella `prodotti`
--
ALTER TABLE `prodotti`
  ADD CONSTRAINT `prodotti_ibfk_1` FOREIGN KEY (`categoria_id`) REFERENCES `categorie` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
